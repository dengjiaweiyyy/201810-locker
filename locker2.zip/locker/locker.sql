create database locker;

set session sql_mode = 'ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION';

create table location (
  id int(11) unsigned primary key auto_increment,
  name varchar(32) not null comment '地点名称',
  comment varchar(32) comment '备注'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into location (name, comment) values ('武汉1', '备注1');
insert into location (name, comment) values ('武汉2', NULL);
insert into location (name) values ('武汉3');


create table locker (
  id int(11) unsigned primary key auto_increment,
  location_id int(11) unsigned comment '投放地标识',
  number int(11) unsigned not null unique key comment '储物柜编号',
  type tinyint(1) not null comment '储物柜类型',
  big_capacity tinyint unsigned comment '大箱体容量',
  small_capacity tinyint unsigned comment '小箱体容量',
  enable_state tinyint(1) not null comment '启动状态',
  connect_state tinyint(1) not null comment '连接状态',
  foreign key (location_id) references location (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into locker (location_id, number, type, big_capacity, small_capacity, enable_state, connect_state) values (1, 1, 1, 0, 10, 1, 1);
insert into locker (location_id, number, type, big_capacity, small_capacity, enable_state, connect_state) values (1, 2, 1, 10, 10, 0, 0);
insert into locker (location_id, number, type, big_capacity, small_capacity, enable_state, connect_state) values (2, 3, 1, 10, 10, 1, 1);
insert into locker (location_id, number, type, big_capacity, small_capacity, enable_state, connect_state) values (2, 4, 1, 10, 10, 0, 0);

create table box (
  id int(11) unsigned primary key auto_increment,
  locker_id int(11) unsigned comment '储物柜标识',
  number int(11) unsigned not null comment '箱体编号',
  state tinyint(1) not null comment '状态',
  foreign key (locker_id) references locker(id),
  unique key (locker_id, number)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into box (locker_id, number, state) values (1, 1, 1);
insert into box (locker_id, number, state) values (1, 2, 0);
insert into box (locker_id, number, state) values (1, 3, 0);
insert into box (locker_id, number, state) values (1, 4, 1);
insert into box (locker_id, number, state) values (1, 5, 0);
insert into box (locker_id, number, state) values (1, 6, 0);
insert into box (locker_id, number, state) values (1, 7, 1);
insert into box (locker_id, number, state) values (1, 8, 0);
insert into box (locker_id, number, state) values (1, 9, 1);
insert into box (locker_id, number, state) values (1, 10, 0);

insert into box (locker_id, number, state) values (3, 1, 0);
insert into box (locker_id, number, state) values (3, 2, 1);
insert into box (locker_id, number, state) values (3, 3, 1);
insert into box (locker_id, number, state) values (3, 4, 1);
insert into box (locker_id, number, state) values (3, 5, 0);
insert into box (locker_id, number, state) values (3, 6, 0);
insert into box (locker_id, number, state) values (3, 7, 0);
insert into box (locker_id, number, state) values (3, 8, 1);
insert into box (locker_id, number, state) values (3, 9, 1);
insert into box (locker_id, number, state) values (3, 10, 0);

insert into box (locker_id, number, state) values (3, 11, 0);
insert into box (locker_id, number, state) values (3, 12, 1);
insert into box (locker_id, number, state) values (3, 13, 1);
insert into box (locker_id, number, state) values (3, 14, 1);
insert into box (locker_id, number, state) values (3, 15, 0);
insert into box (locker_id, number, state) values (3, 16, 0);
insert into box (locker_id, number, state) values (3, 17, 0);
insert into box (locker_id, number, state) values (3, 18, 1);
insert into box (locker_id, number, state) values (3, 19, 1);
insert into box (locker_id, number, state) values (3, 20, 0);

create table cost_record (
  id int(11) unsigned primary key auto_increment,
  box_id int(11) unsigned not null comment '箱体标识',
  cost decimal(5,2) unsigned not null comment '费用',
  identity char(18) not null comment '身份证号',
  open_id varchar(32) not null comment '微信open_id',
  create_time timestamp not null default CURRENT_TIMESTAMP comment '记录创建时间',
  update_time timestamp not null default CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP comment '记录修改时间',
  start_time timestamp not null comment '开始时间',
  end_time timestamp not null comment '结束时间',
  pay_time timestamp not null comment '支付时间',
  pay_state tinyint(1) not null comment '支付状态',
  comment varchar(32) comment '备注',
  foreign key (box_id) references box (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

create table maintenance_person (
  id int(11) unsigned primary key auto_increment,
  name varchar(32) not null comment '维修人员姓名',
  account varchar(32) not null comment '账号',
  password varchar(32) not null comment '密码'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into maintenance_person (name, account, password) values ('张三', '420123123456781234', '123456');
insert into maintenance_person (name, account, password) values ('李四', '420123123456781235', '123456');
insert into maintenance_person (name, account, password) values ('王五', '420123123456781236', '123456');

create table maintenance_record (
  id int(11) unsigned primary key auto_increment,
  create_time timestamp not null default CURRENT_TIMESTAMP comment '记录创建时间',
  update_time timestamp not null default CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP comment '记录修改时间',
  date timestamp not null comment '日期',
  locker_id int(11) unsigned not null comment '储物柜标识',
  maintenance_person_id int(11) unsigned not null comment '维修人员标识',
  foreign key (locker_id) references locker (id),
  foreign key (maintenance_person_id) references maintenance_person (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

create table locker_status (
  id int(11) unsigned primary key auto_increment,
  date timestamp not null comment '日期',
  locker_id int(11) unsigned not null comment '储物柜标识',
  small_use_times smallint unsigned comment '小箱体使用次数',
  big_use_times smallint unsigned comment '大箱体使用次数',
  small_total_income decimal(6,2) unsigned not null comment '所有小箱体总收入',
  big_total_income decimal(6,2) unsigned not null comment '所有大箱体总收入',
  foreign key (locker_id) references locker (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

create table charge_scheme (
  id int(11) unsigned primary key auto_increment,
  shceme_name varchar(32) unique key comment '方案名称'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into charge_scheme (shceme_name) values ('方案1');
insert into charge_scheme (shceme_name) values ('方案2');
insert into charge_scheme (shceme_name) values ('方案3');

create table charge_standard (
  id int(11) unsigned primary key auto_increment,
  shceme_id int(11) unsigned comment '关联方案标识',
  price decimal(5, 2) not null comment '单价',
  upper_limit decimal(5, 2) not null comment '上限',
  type tinyint(1) not null comment '类型',
  foreign key (shceme_id) references charge_scheme (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

insert into charge_standard (shceme_id, price, upper_limit, type) values (1, 2, 16, 1);
insert into charge_standard (shceme_id, price, upper_limit, type) values (1, 3, 24, 2);
insert into charge_standard (shceme_id, price, upper_limit, type) values (2, 3, 24, 1);
insert into charge_standard (shceme_id, price, upper_limit, type) values (2, 4, 32, 2);
insert into charge_standard (shceme_id, price, upper_limit, type) values (3, 4, 32, 1);
insert into charge_standard (shceme_id, price, upper_limit, type) values (3, 5, 40, 2);
