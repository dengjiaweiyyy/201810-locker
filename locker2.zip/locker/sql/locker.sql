/*
Navicat MySQL Data Transfer

Source Server         : master
Source Server Version : 50720
Source Host           : localhost:3306
Source Database       : locker

Target Server Type    : MYSQL
Target Server Version : 50720
File Encoding         : 65001

Date: 2018-10-09 13:57:23
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `box`
-- ----------------------------
DROP TABLE IF EXISTS `box`;
CREATE TABLE `box` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `locker_id` int(11) unsigned NOT NULL COMMENT '储物柜标识',
  `no` int(8) NOT NULL COMMENT '格口编号',
  `capacity` int(8) DEFAULT NULL COMMENT '容量',
  `size_id` int(11) NOT NULL,
  `state` tinyint(1) NOT NULL COMMENT '状态（1：使用中；0：空闲）',
  PRIMARY KEY (`id`),
  UNIQUE KEY `locker_id` (`locker_id`,`no`),
  CONSTRAINT `fk_box_locker_locker_id` FOREIGN KEY (`locker_id`) REFERENCES `locker` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of box
-- ----------------------------
INSERT INTO `box` VALUES ('1', '1', '1', '40', '0', '0');
INSERT INTO `box` VALUES ('2', '1', '2', '50', '0', '0');
INSERT INTO `box` VALUES ('3', '1', '3', '0', '0', '0');
INSERT INTO `box` VALUES ('4', '1', '4', '0', '0', '0');
INSERT INTO `box` VALUES ('5', '1', '5', '0', '0', '0');
INSERT INTO `box` VALUES ('6', '1', '6', '0', '0', '0');
INSERT INTO `box` VALUES ('7', '1', '7', '0', '0', '0');
INSERT INTO `box` VALUES ('8', '1', '8', '0', '0', '0');
INSERT INTO `box` VALUES ('9', '1', '9', '0', '0', '0');
INSERT INTO `box` VALUES ('10', '1', '10', null, '0', '0');
INSERT INTO `box` VALUES ('11', '3', '1', null, '0', '0');
INSERT INTO `box` VALUES ('12', '3', '2', null, '0', '1');
INSERT INTO `box` VALUES ('13', '3', '3', null, '0', '1');
INSERT INTO `box` VALUES ('14', '3', '4', null, '0', '1');
INSERT INTO `box` VALUES ('15', '3', '5', null, '0', '0');
INSERT INTO `box` VALUES ('16', '3', '6', null, '0', '0');
INSERT INTO `box` VALUES ('17', '3', '7', null, '0', '0');
INSERT INTO `box` VALUES ('18', '3', '8', null, '0', '1');
INSERT INTO `box` VALUES ('19', '3', '9', null, '0', '1');
INSERT INTO `box` VALUES ('20', '3', '10', null, '0', '0');
INSERT INTO `box` VALUES ('21', '3', '11', null, '0', '0');
INSERT INTO `box` VALUES ('22', '3', '12', null, '0', '1');
INSERT INTO `box` VALUES ('23', '3', '13', null, '0', '1');
INSERT INTO `box` VALUES ('24', '3', '14', null, '0', '1');
INSERT INTO `box` VALUES ('25', '3', '15', null, '0', '0');
INSERT INTO `box` VALUES ('26', '3', '16', null, '0', '0');
INSERT INTO `box` VALUES ('27', '3', '17', null, '0', '0');
INSERT INTO `box` VALUES ('28', '3', '18', null, '0', '1');
INSERT INTO `box` VALUES ('29', '3', '19', null, '0', '1');
INSERT INTO `box` VALUES ('30', '3', '20', null, '0', '0');

-- ----------------------------
-- Table structure for `charge_scheme`
-- ----------------------------
DROP TABLE IF EXISTS `charge_scheme`;
CREATE TABLE `charge_scheme` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `shceme_name` varchar(32) DEFAULT NULL COMMENT '方案名称',
  `memo` varchar(45) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  UNIQUE KEY `shceme_name` (`shceme_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of charge_scheme
-- ----------------------------
INSERT INTO `charge_scheme` VALUES ('1', '方案1', null);
INSERT INTO `charge_scheme` VALUES ('2', '方案2', null);
INSERT INTO `charge_scheme` VALUES ('3', '方案3', null);

-- ----------------------------
-- Table structure for `charge_standard`
-- ----------------------------
DROP TABLE IF EXISTS `charge_standard`;
CREATE TABLE `charge_standard` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `shceme_id` int(11) unsigned DEFAULT NULL COMMENT '关联方案标识',
  `capacity` int(11) DEFAULT NULL COMMENT '容量\n',
  `price` decimal(5,2) DEFAULT NULL COMMENT '单价',
  `minimum_charge` decimal(5,2) DEFAULT NULL COMMENT '最低收费',
  `upper_limit` decimal(5,2) DEFAULT NULL COMMENT '单日上限',
  PRIMARY KEY (`id`),
  KEY `shceme_id` (`shceme_id`),
  CONSTRAINT `charge_standard_ibfk_1` FOREIGN KEY (`shceme_id`) REFERENCES `charge_scheme` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of charge_standard
-- ----------------------------
INSERT INTO `charge_standard` VALUES ('1', '1', '40', '2.00', '2.00', '16.00');
INSERT INTO `charge_standard` VALUES ('2', '1', '50', '3.00', '3.00', '24.00');
INSERT INTO `charge_standard` VALUES ('3', '2', '0', '3.00', '0.00', '24.00');
INSERT INTO `charge_standard` VALUES ('4', '2', '0', '4.00', '0.00', '32.00');
INSERT INTO `charge_standard` VALUES ('5', '3', '0', '4.00', '0.00', '32.00');
INSERT INTO `charge_standard` VALUES ('6', '3', '0', '5.00', '0.00', '40.00');

-- ----------------------------
-- Table structure for `cost_record`
-- ----------------------------
DROP TABLE IF EXISTS `cost_record`;
CREATE TABLE `cost_record` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `box_id` int(11) unsigned DEFAULT NULL COMMENT '箱体标识',
  `capacity` int(8) DEFAULT NULL,
  `cost` decimal(5,2) unsigned DEFAULT NULL COMMENT '费用',
  `out_cost` decimal(5,2) DEFAULT NULL,
  `identity` char(18) DEFAULT NULL COMMENT '身份证号',
  `order_id` varchar(32) DEFAULT NULL,
  `out_order_id` varchar(32) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL COMMENT '记录创建时间',
  `out_create_time` datetime DEFAULT NULL,
  `pay_time` datetime DEFAULT NULL COMMENT '支付时间',
  `out_pay_time` datetime DEFAULT NULL,
  `pay_state` tinyint(1) DEFAULT NULL COMMENT '0:未支付   1：已支付    支付状态',
  `comment` varchar(32) DEFAULT NULL COMMENT '备注',
  `platformorder_id` varchar(100) DEFAULT NULL,
  `buyer_id` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `code` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `box_id` (`box_id`),
  CONSTRAINT `cost_record_ibfk_1` FOREIGN KEY (`box_id`) REFERENCES `box` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cost_record
-- ----------------------------
INSERT INTO `cost_record` VALUES ('11', '2', '50', '3.00', '24.00', null, '20180928230817121', '20180928231022460', '2018-09-28 12:08:17', '2018-09-28 23:10:22', '2018-09-28 12:09:15', '2018-09-28 23:10:46', '2', null, '2018092821001004800200677931', '2088102175797803', '18571845263', '610102');

-- ----------------------------
-- Table structure for `info`
-- ----------------------------
DROP TABLE IF EXISTS `info`;
CREATE TABLE `info` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) DEFAULT NULL,
  `introduction` varchar(500) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `charge_standard` varchar(500) DEFAULT NULL,
  `locker_id` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of info
-- ----------------------------
INSERT INTO `info` VALUES ('1', '小红柜', '存取物品是小红柜提供给用户的主要功能。 如何寄存：点击寄存物品，选择寄存柜大小，扫描微信、支付宝二维码付费，柜门打开，存入物品，关闭柜门。 如何取：点击取出物品，扫描微信、支付宝二维码，结算费用，柜门打开，取出物品，关闭柜门。', null, null, '123456', '大寄存柜每小时收费3元，超过8小时，以一天计费，每天收费24元，超过48小时，您没有取走您的物品，我公司有权处理您寄存的物品。\r\n小寄存柜每小时收费2元，超过8小时，以一天计费，每天收费16元，超过48小时，您没有取走您的物品，我公司有权处理您寄存的物品。\r\n寄存物品重量不要超过10公斤。\r\n贵重物品请随身携带，不要寄存。', '1');

-- ----------------------------
-- Table structure for `location`
-- ----------------------------
DROP TABLE IF EXISTS `location`;
CREATE TABLE `location` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '投放地自增ID',
  `zip_code` varchar(8) NOT NULL COMMENT '邮编',
  `city` varchar(254) NOT NULL COMMENT '投放城市',
  `address` varchar(512) NOT NULL COMMENT '投放地详细地址',
  `memo` varchar(512) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of location
-- ----------------------------
INSERT INTO `location` VALUES ('1', '027', '武汉市', '雄楚大街999号', '');

-- ----------------------------
-- Table structure for `locker`
-- ----------------------------
DROP TABLE IF EXISTS `locker`;
CREATE TABLE `locker` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `location_id` int(11) DEFAULT NULL COMMENT '投放地标识',
  `no` varchar(16) NOT NULL COMMENT '储物柜编号',
  `type` tinyint(1) NOT NULL COMMENT '储物柜类型',
  `enable_state` tinyint(1) NOT NULL COMMENT '启用状态',
  `create_time` char(16) NOT NULL COMMENT '投放时间',
  PRIMARY KEY (`id`),
  KEY `location_id` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of locker
-- ----------------------------
INSERT INTO `locker` VALUES ('1', '1', '1', '1', '1', '');
INSERT INTO `locker` VALUES ('2', '1', '2', '1', '0', '');
INSERT INTO `locker` VALUES ('3', '2', '3', '1', '1', '');
INSERT INTO `locker` VALUES ('4', '2', '4', '1', '0', '');

-- ----------------------------
-- Table structure for `locker_charge`
-- ----------------------------
DROP TABLE IF EXISTS `locker_charge`;
CREATE TABLE `locker_charge` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `locker_id` int(11) unsigned DEFAULT NULL,
  `charge_scheme_id` int(11) unsigned DEFAULT NULL,
  `begin_time` char(14) DEFAULT NULL,
  `memo` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `lockerid_UNIQUE` (`locker_id`),
  UNIQUE KEY `charge_scheme_id_UNIQUE` (`charge_scheme_id`),
  CONSTRAINT `fk_charge_scheme_id` FOREIGN KEY (`charge_scheme_id`) REFERENCES `charge_scheme` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_locker_id` FOREIGN KEY (`locker_id`) REFERENCES `locker` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of locker_charge
-- ----------------------------
INSERT INTO `locker_charge` VALUES ('1', '1', '1', '2019', null);

-- ----------------------------
-- Table structure for `locker_status`
-- ----------------------------
DROP TABLE IF EXISTS `locker_status`;
CREATE TABLE `locker_status` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '日期',
  `locker_id` int(11) unsigned NOT NULL COMMENT '储物柜标识',
  `small_use_times` smallint(5) unsigned DEFAULT NULL COMMENT '小箱体使用次数',
  `big_use_times` smallint(5) unsigned DEFAULT NULL COMMENT '大箱体使用次数',
  `small_total_income` decimal(6,2) unsigned NOT NULL COMMENT '所有小箱体总收入',
  `big_total_income` decimal(6,2) unsigned NOT NULL COMMENT '所有大箱体总收入',
  PRIMARY KEY (`id`),
  KEY `locker_id` (`locker_id`),
  CONSTRAINT `locker_status_ibfk_1` FOREIGN KEY (`locker_id`) REFERENCES `locker` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of locker_status
-- ----------------------------

-- ----------------------------
-- Table structure for `maintenance_person`
-- ----------------------------
DROP TABLE IF EXISTS `maintenance_person`;
CREATE TABLE `maintenance_person` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL COMMENT '维修人员姓名',
  `account` varchar(32) NOT NULL COMMENT '账号',
  `password` varchar(32) NOT NULL COMMENT '密码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of maintenance_person
-- ----------------------------
INSERT INTO `maintenance_person` VALUES ('1', '张三', '420123123456781234', '123456');
INSERT INTO `maintenance_person` VALUES ('2', '李四', '420123123456781235', '123456');
INSERT INTO `maintenance_person` VALUES ('3', '王五', '420123123456781236', '123456');

-- ----------------------------
-- Table structure for `maintenance_record`
-- ----------------------------
DROP TABLE IF EXISTS `maintenance_record`;
CREATE TABLE `maintenance_record` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `create_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '记录创建时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '记录修改时间',
  `date` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '日期',
  `locker_id` int(11) unsigned NOT NULL COMMENT '储物柜标识',
  `maintenance_person_id` int(11) unsigned NOT NULL COMMENT '维修人员标识',
  PRIMARY KEY (`id`),
  KEY `locker_id` (`locker_id`),
  KEY `maintenance_person_id` (`maintenance_person_id`),
  CONSTRAINT `maintenance_record_ibfk_1` FOREIGN KEY (`locker_id`) REFERENCES `locker` (`id`),
  CONSTRAINT `maintenance_record_ibfk_2` FOREIGN KEY (`maintenance_person_id`) REFERENCES `maintenance_person` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of maintenance_record
-- ----------------------------

-- ----------------------------
-- Table structure for `role`
-- ----------------------------
DROP TABLE IF EXISTS `role`;
CREATE TABLE `role` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '角色id-自增',
  `code` varchar(45) NOT NULL COMMENT '角色code',
  `name` varchar(45) NOT NULL COMMENT '角色名',
  `memo` varchar(512) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of role
-- ----------------------------
INSERT INTO `role` VALUES ('1', 'admin', '管理员', null);
INSERT INTO `role` VALUES ('2', 'contractor', '承包商', null);
INSERT INTO `role` VALUES ('3', 'maintainer', '维护人员', null);

-- ----------------------------
-- Table structure for `size`
-- ----------------------------
DROP TABLE IF EXISTS `size`;
CREATE TABLE `size` (
  `id` int(11) NOT NULL,
  `description` varchar(64) NOT NULL COMMENT '长x宽x高',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='柜口尺寸表述';

-- ----------------------------
-- Records of size
-- ----------------------------

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增ID',
  `userid` varchar(32) NOT NULL COMMENT '用户ID',
  `password` varchar(45) NOT NULL COMMENT '密码',
  `roleid` int(11) unsigned NOT NULL COMMENT '角色：admin（管理员）; contractor（承包商）; maintainer（维护人员）',
  `create_time` char(14) NOT NULL,
  `memo` varchar(512) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roleid_UNIQUE` (`roleid`),
  CONSTRAINT `fk_role_user_roleid` FOREIGN KEY (`roleid`) REFERENCES `role` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'test', '098f6bcd4621d373cade4e832627b4f6', '1', '201808131137', null);
