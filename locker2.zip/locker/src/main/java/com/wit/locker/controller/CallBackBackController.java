package com.wit.locker.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.wit.locker.service.pay.CallBackBackService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
@RequestMapping("/alibaba/callBackBack")
public class CallBackBackController {

	private static final String PAY_SUCCESS="index";
	
	private static final String PAY_ERROR="payerror";
	
	@Autowired
	private CallBackBackService callBackBackService;
	
	
	
	
	//同步通知
	@RequestMapping("/returnUrl")
	public void synCallBack(HttpServletRequest request,HttpServletResponse response) {
		response.setContentType("text/html;charset=utf-8");
		//获取支付宝GET过来反馈信息
		Map<String,String> params = new HashMap<String,String>();
		Map<String,String[]> requestParams = request.getParameterMap();
		for (Iterator<String> iter = requestParams.keySet().iterator(); iter.hasNext();) {
			String name = (String) iter.next();
			String[] values = (String[]) requestParams.get(name);
			String valueStr = "";
			for (int i = 0; i < values.length; i++) {
				valueStr = (i == values.length - 1) ? valueStr + values[i]
						: valueStr + values[i] + ",";
			}
			//乱码解决，这段代码在出现乱码时使用
				try {
					valueStr = new String(valueStr.getBytes("ISO-8859-1"), "utf-8");
				} catch (UnsupportedEncodingException e) {
					// TODO Auto-generated catch block
					//报错页面
					e.printStackTrace();
				
				}
				params.put(name, valueStr);
		}
		log.info("#################支付宝同步回调synCallBack开始params："+params);
		JSONObject  jSONObject=callBackBackService.synCallBack(params);
		log.info("#################支付宝同步回调synCallBack结束params："+params);
		if(jSONObject.get("outTradeNo")==null) {
			//报错页面
			
		}
		//获取浏览器输出流
		PrintWriter writer = null;
		try {
			writer=response.getWriter();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//报错页面
			
		}
	
		String outTradeNo=(String) jSONObject.get("outTradeNo");
		String tradeNo=(String) jSONObject.get("tradeNo");
		String totalAmount=(String) jSONObject.get("totalAmount");
		//封装成html通过浏览器模拟提交
		String htmlForm="<form name='punchout_form'"
				+ " method='post'"
				+ " action='http://hhcrby.natappfree.cc/alibaba/callBackBack/synSuccessPage' >" + 
				"	<input type='hidden' name='outTradeNo' value='"+outTradeNo+"'>" + 
				"	<input type='hidden' name='tradeNo' value='"+tradeNo+"'>" + 
				"	<input type='hidden' name='totalAmount' value='"+totalAmount+"'>" + 
				"	<input type='submit' value='立即支付' style='display:none'>" + 
				"</form>" + 
				"<script>document.forms[0].submit();</script>";
		writer.println(htmlForm);
		
	
	};
	
	//以post表达隐藏参数
	@RequestMapping(value="synSuccessPage",method=RequestMethod.POST)
	public ModelAndView synSuccessPage(String outTradeNo,String tradeNo,String totalAmount,HttpServletRequest request) {
		request.setAttribute("outTradeNo", outTradeNo);
		request.setAttribute("tradeNo", tradeNo);
		request.setAttribute("totalAmount", totalAmount);
		ModelAndView modelAndView = new ModelAndView("redirect:/index");
		return modelAndView;
	}
	
	
	
	//异步通知
	@ResponseBody
	@RequestMapping("/notifyUrl")
	public String asynCallBack(HttpServletRequest request) {
		//获取支付宝GET过来反馈信息
		Map<String,String> params = new HashMap<String,String>();
		Map<String,String[]> requestParams = request.getParameterMap();
		for (Iterator<String> iter = requestParams.keySet().iterator(); iter.hasNext();) {
			String name = (String) iter.next();
			String[] values = (String[]) requestParams.get(name);
			String valueStr = "";
			for (int i = 0; i < values.length; i++) {
				valueStr = (i == values.length - 1) ? valueStr + values[i]
						: valueStr + values[i] + ",";
			}
			//异步支付宝返回参数以post提交不会产生乱码
				params.put(name, valueStr);
		}
		
		log.info("#################支付宝异步回调asynCallBack开始params："+params);
		String  responseStr=callBackBackService.asynCallBack(params);
		log.info("#################支付宝异步回调asynCallBack结束params："+params);
		
		
		
		return responseStr;
	};
	
}
