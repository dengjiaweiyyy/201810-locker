package com.wit.locker.controller;

import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.wit.locker.domain.Box;
import com.wit.locker.domain.ChargeStandard;
import com.wit.locker.domain.CostRecord;
import com.wit.locker.domain.Info;
import com.wit.locker.mapper.BoxMapper;
import com.wit.locker.service.BoxService;
import com.wit.locker.service.ChargeStandardService;
import com.wit.locker.service.CostRecordService;
import com.wit.locker.service.InfoService;
import com.wit.locker.service.pay.PayBackService;
import com.wit.locker.service.pay.PayService;
import com.wit.locker.utils.OrderUtil;
import com.wit.locker.utils.common.Constants;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class CostRecordController {

	@Autowired
	private PayService payService;
	
	@Autowired
	private PayBackService payBackService;
	
	@Autowired
	private BoxMapper boxMapper;
	
	@Autowired
	private InfoService infoService;
	
	
	@Autowired
	private ChargeStandardService chargeStandardService;
	
	@Autowired
	private CostRecordService costRecordService;
	
	
	@Autowired
	private BoxService boxService;
	
	@RequestMapping(value="/getPay", method = {RequestMethod.POST})
	@ResponseBody
	public String getPay(Long capacity) {
		return "success";
	}
	
	@RequestMapping(value="/getPayBack", method = {RequestMethod.POST})
	@ResponseBody
	public String getPayBack(String code) {
		return "success";
	}
	
	@RequestMapping(value="/diaPlayInfo", method = {RequestMethod.GET})
	public String getPay(String phone, String toDate,String fromDate,String totalPrice,String code,Model model) {
		
		model.addAttribute("phone", " 手机号码:"+phone);
		model.addAttribute("toDate", "取物时间:"+toDate);
		model.addAttribute("fromDate","寄存时间:"+ fromDate);
		model.addAttribute("totalPrice", " 消费金额(元):"+totalPrice);
		model.addAttribute("code", code);
		Long lockerId=1l;
		Info info = infoService.getInfoByLockerId(lockerId);
		model.addAttribute("title", info.getTitle());
		return "withdraw";
	}
	
	

	@RequestMapping(value="/uploadCapacity", method = {RequestMethod.GET})
	public String uploadCapacity(Long capacity,Model model) {
		model.addAttribute("capacity", capacity);
		Long lockerId=1l;
		Info info = infoService.getInfoByLockerId(lockerId);
		model.addAttribute("title", info.getTitle());
		return "uploadCapacity";
	}
	
	
	
	//开柜 修改后台的状态
	@RequestMapping(value="/freeOpen",method=RequestMethod.GET)
	public ModelAndView freeOpen(String phone,Double totalPrice,String code,HttpServletRequest request) {
		
		//1.根据phone,code,且pay_state为1找出CostRecord
		CostRecord  costRecord  = costRecordService.getPayInfoByCodeAndPhone(phone, code);
		//2.根据orderId去修改out_cost   out_pay_time
		costRecord.setOutCost(totalPrice);
		costRecord.setPayState(2);
		Integer result = costRecordService.updatePayInfoInFree(costRecord);
		Box box = new Box();
		box.setId(costRecord.getBoxId());
		box.setState(0);
		Integer boxresult= boxMapper.updateBox(box);
		//修改失败
		
		if(boxresult<=0) {
			ModelAndView modelAndView = new ModelAndView("redirect:/updatePayBackFreeError");
			return modelAndView;
		}
		
		if(result<0) {
			ModelAndView modelAndView = new ModelAndView("redirect:/updatePayBackFreeError");
			return modelAndView;
		}else {
			ModelAndView modelAndView = new ModelAndView("redirect:/index");
			return modelAndView;
		}
	}
	
	
	
	@RequestMapping(value="/getCode", method = {RequestMethod.POST})
	@ResponseBody
	public String getCode(String code) throws Exception {
		//1.根据code获取CostRecord
		CostRecord  costRecord  = payService.getPayInfoByCode(code);
		if(costRecord==null) {
			return "costRecordNull";
		}
		Long lockId=1l;
		Long boxId = costRecord.getBoxId();
		Long capacity = costRecord.getCapacity();
		String phone = costRecord.getPhone();
		Date patTime = costRecord.getPayTime();
		Date nowTime = new Date();
		SimpleDateFormat simpleFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm");//如2016-08-10 20:40
		String fromDate = simpleFormat.format(patTime);
		String toDate = simpleFormat.format(nowTime);
		long from = simpleFormat.parse(fromDate).getTime();
		long to = simpleFormat.parse(toDate).getTime();
		int hours = (int) ((to - from)/(1000 * 60 * 60));
		ChargeStandard chargeStandard = chargeStandardService.getChargeStandardByCapacity(lockId, capacity);
		if(chargeStandard==null) {
			return "chargeStandardNull";
		}
		double price = chargeStandard.getPrice();
		double upperLimit = chargeStandard.getUpperLimit();
		double totalPrice = hours*price;
		//如果费用比最大费用高就把费用改为最大数字
		if(totalPrice>upperLimit) {
			totalPrice=upperLimit;
		}
		return phone+","+toDate+","+fromDate+","+totalPrice;
	}
	
	
	//?phone="+str[0]+"&totalPrice="+str[3]+"&code="+code;
	@RequestMapping(value="/aliPayBack", method = {RequestMethod.GET})
	public void aliPayBack(String phone,Double totalPrice,String code,HttpServletResponse response) throws Exception {
		response.setContentType("text/html;charset=utf-8");
		PrintWriter writer=response.getWriter();
		//1.根据phone,code,且pay_state为1找出CostRecord
		CostRecord  costRecord  = costRecordService.getPayInfoByCodeAndPhone(phone, code);
		String orderId = OrderUtil.getOrderIdByTime();
		//2.修改out_cost与out_create_time orderId
		costRecord.setOutCost(totalPrice);
		
			JSONObject jSONObject=payBackService.getPayBackHtml(costRecord);
			if(jSONObject.get("payHtml")==null) {
				writer.println("系统错误");
				return ;
			}
			//3.返回可执行的html元素给客户端
			String payHtml=(String) jSONObject.get("payHtml");
			log.info("#########################payHtml:"+payHtml);
			//4.返回到页面进行渲染
			writer.println(payHtml);
			writer.close();
		
	}
	
	
	
	
	
	@RequestMapping(value="/aliPay", method = {RequestMethod.GET})
	public void aliPay(Long capacity,String phone,HttpServletResponse response) throws Exception {
		response.setContentType("text/html;charset=utf-8");
		PrintWriter writer=response.getWriter();
		//获取locker_id=1,capacity为capacity的所有记录
		Long lockId=1l;
		Long boxId = boxService.getBoxIdByLockerIdAndCapacity(lockId, capacity);
		if(boxId==-1) {
			writer.println("<script language='javascript'>alert('小红柜没有空闲的啦!');window.history.back();</script>");
			writer.close();
			
		}else {
			String orderId = OrderUtil.getOrderIdByTime();
			//根据容量查询最低价格
			ChargeStandard chargeStandard = chargeStandardService.getChargeStandardByCapacity(lockId,capacity);
			double cost=chargeStandard.getPrice(); 
			CostRecord costRecord = new CostRecord();
			costRecord.setBoxId(boxId);
			costRecord.setCost(cost);
			
			costRecord.setOrderId(orderId);
			costRecord.setPayState(0);
			costRecord.setPhone(phone);
			costRecord.setCapacity(capacity);
			JSONObject jSONObject=payService.getPayHtml(costRecord);
			if(jSONObject.get("payHtml")==null) {
				writer.println("系统错误");
				return ;
			}
			//3.返回可执行的html元素给客户端
			String payHtml=(String) jSONObject.get("payHtml");
			log.info("#########################payHtml:"+payHtml);
			//4.返回到页面进行渲染
			writer.println(payHtml);
			writer.close();
		}
	}
	
	
	
}
