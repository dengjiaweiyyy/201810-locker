package com.wit.locker.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.wit.locker.domain.Box;
import com.wit.locker.domain.Info;
import com.wit.locker.service.BoxService;
import com.wit.locker.service.InfoService;

@Controller
public class LockerController {
	

	@Autowired
	private InfoService infoService;
	
	@Autowired
	private BoxService boxService;
	

	
	@RequestMapping("/index")
	public String index(Model model) {
		Long lockerId=1l;
		Info info = infoService.getInfoByLockerId(lockerId);
		model.addAttribute("title", info.getTitle());
		model.addAttribute("introduction", info.getIntroduction());
		model.addAttribute("phone", "服务热线:"+info.getPhone());
		//获取空闲格口数
		List<Box> freeBox= boxService.getFreeBox(lockerId);
		model.addAttribute("freeBoxSize", "空闲格口数:"+freeBox.size());
		return "index";
	}
	
	
	@RequestMapping("/choose")
	public String choose(Model model) {
		Long lockerId=1l;
		Info info = infoService.getInfoByLockerId(lockerId);
		model.addAttribute("title", info.getTitle());
		model.addAttribute("chargeStandard", info.getChargeStandard());
		//获取大的空闲格口数
		List<Box> freeBigBox= boxService.getBoxByLockerIdAndCapacity(lockerId, 50l);
		model.addAttribute("freeBigBoxSize", "空闲格口数:"+freeBigBox.size());
		//获取小的空闲格口数
		List<Box> freeSmallBox= boxService.getBoxByLockerIdAndCapacity(lockerId, 40l);
		model.addAttribute("freeSmallBoxSize", "空闲格口数:"+freeSmallBox.size());
		return "choose";
	}
	
	
	@RequestMapping("/updatePayBackFreeError")
	public String updatePayBackFreeError() {
		return "error";
	}
	
	@RequestMapping("/withdraw")
	public String withdraw(Model model) {
		Long lockerId=1l;
		Info info = infoService.getInfoByLockerId(lockerId);
		model.addAttribute("title", info.getTitle());
		return "withdraw";
	}
	
	@RequestMapping("/inputCode")
	public String inputCode(Model model) {
		Long lockerId=1l;
		Info info = infoService.getInfoByLockerId(lockerId);
		model.addAttribute("title", info.getTitle());
		return "inputCode";
	}
	
	@RequestMapping("/upload")
	public String upload(Model model) {
		Long lockerId=1l;
		Info info = infoService.getInfoByLockerId(lockerId);
		model.addAttribute("title", info.getTitle());
		return "uploadCapacity";
	}
	
	
	
	
}
