package com.wit.locker.domain;



public class Box {

    private Long id;
    private Long lockerId;
    private String no;
    private Long capacity;
    private Integer state;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getLockerId() {
		return lockerId;
	}
	public void setLockerId(Long lockerId) {
		this.lockerId = lockerId;
	}
	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public Long getCapacity() {
		return capacity;
	}
	public void setCapacity(Long capacity) {
		this.capacity = capacity;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	@Override
	public String toString() {
		return "Box [id=" + id + ", lockerId=" + lockerId + ", no=" + no + ", capacity=" + capacity + ", state=" + state
				+ "]";
	}
	
    
}
