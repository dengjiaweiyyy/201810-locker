package com.wit.locker.domain;



public class ChargeScheme {

    
    private Long id;

    private String shcemeName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getShcemeName() {
		return shcemeName;
	}

	public void setShcemeName(String shcemeName) {
		this.shcemeName = shcemeName;
	}

	@Override
	public String toString() {
		return "ChargeScheme [id=" + id + ", shcemeName=" + shcemeName + "]";
	}

	
   
}
