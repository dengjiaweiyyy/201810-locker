package com.wit.locker.domain;

import java.util.Date;


public class CostRecord {

  
    private Long id;

    private Long boxId;
    private Long capacity;
    private Double cost;
    private Double outCost;
    private String identity;
    private String orderId;
    private String outOrderId;
    private Date createTime;
    private Date outCreateTime;
    private Date payTime;
    private Date outPayTime;
    private Integer payState;
    private String comment;
    private String platformorderId;
    private String buyerId;
    private String phone;
    private String code;
    
	public Long getCapacity() {
		return capacity;
	}
	public void setCapacity(Long capacity) {
		this.capacity = capacity;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getBoxId() {
		return boxId;
	}
	public void setBoxId(Long boxId) {
		this.boxId = boxId;
	}
	public Double getCost() {
		return cost;
	}
	public void setCost(Double cost) {
		this.cost = cost;
	}
	public Double getOutCost() {
		return outCost;
	}
	public void setOutCost(Double outCost) {
		this.outCost = outCost;
	}
	public String getIdentity() {
		return identity;
	}
	public void setIdentity(String identity) {
		this.identity = identity;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getOutOrderId() {
		return outOrderId;
	}
	public void setOutOrderId(String outOrderId) {
		this.outOrderId = outOrderId;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getOutCreateTime() {
		return outCreateTime;
	}
	public void setOutCreateTime(Date outCreateTime) {
		this.outCreateTime = outCreateTime;
	}
	public Date getPayTime() {
		return payTime;
	}
	public void setPayTime(Date payTime) {
		this.payTime = payTime;
	}
	public Date getOutPayTime() {
		return outPayTime;
	}
	public void setOutPayTime(Date outPayTime) {
		this.outPayTime = outPayTime;
	}
	public Integer getPayState() {
		return payState;
	}
	public void setPayState(Integer payState) {
		this.payState = payState;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getPlatformorderId() {
		return platformorderId;
	}
	public void setPlatformorderId(String platformorderId) {
		this.platformorderId = platformorderId;
	}
	public String getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(String buyerId) {
		this.buyerId = buyerId;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	@Override
	public String toString() {
		return "CostRecord [id=" + id + ", boxId=" + boxId + ", cost=" + cost + ", outCost=" + outCost + ", identity="
				+ identity + ", orderId=" + orderId + ", outOrderId=" + outOrderId + ", createTime=" + createTime
				+ ", outCreateTime=" + outCreateTime + ", payTime=" + payTime + ", outPayTime=" + outPayTime
				+ ", payState=" + payState + ", comment=" + comment + ", platformorderId=" + platformorderId
				+ ", buyerId=" + buyerId + ", phone=" + phone + ", code=" + code + ", getId()=" + getId()
				+ ", getBoxId()=" + getBoxId() + ", getCost()=" + getCost() + ", getOutCost()=" + getOutCost()
				+ ", getIdentity()=" + getIdentity() + ", getOrderId()=" + getOrderId() + ", getOutOrderId()="
				+ getOutOrderId() + ", getCreateTime()=" + getCreateTime() + ", getOutCreateTime()="
				+ getOutCreateTime() + ", getPayTime()=" + getPayTime() + ", getOutPayTime()=" + getOutPayTime()
				+ ", getPayState()=" + getPayState() + ", getComment()=" + getComment() + ", getPlatformorderId()="
				+ getPlatformorderId() + ", getBuyerId()=" + getBuyerId() + ", getPhone()=" + getPhone()
				+ ", getCode()=" + getCode() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
    
	
   
	
}
