package com.wit.locker.domain;

import java.util.Date;

public class Info {

    private Long id;
    private Long lockerId;
    private String title;
    private String introduction;
    private String phone;
    private String chargeStandard;
    private Date createTime;
    private Date updateTime;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getLockerId() {
		return lockerId;
	}
	public void setLockerId(Long lockerId) {
		this.lockerId = lockerId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getIntroduction() {
		return introduction;
	}
	public void setIntroduction(String introduction) {
		this.introduction = introduction;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getChargeStandard() {
		return chargeStandard;
	}
	public void setChargeStandard(String chargeStandard) {
		this.chargeStandard = chargeStandard;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	@Override
	public String toString() {
		return "Info [id=" + id + ", lockerId=" + lockerId + ", title=" + title + ", introduction=" + introduction
				+ ", phone=" + phone + ", chargeStandard=" + chargeStandard + ", createTime=" + createTime
				+ ", updateTime=" + updateTime + "]";
	}
    

    
}
