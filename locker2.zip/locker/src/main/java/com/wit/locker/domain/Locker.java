package com.wit.locker.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Locker {

    @Id
    @GeneratedValue
    private Long id;

    private Long locationId;
    private Long number;
    private Integer type;
    private Integer bigCapacity;
    private Integer smallCapacity;
    private Integer enableState;
    private Integer connectState;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getLocationId() {
        return locationId;
    }

    public void setLocationId(Long locationId) {
        this.locationId = locationId;
    }

    public Long getNumber() {
        return number;
    }

    public void setNumber(Long number) {
        this.number = number;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getBigCapacity() {
        return bigCapacity;
    }

    public void setBigCapacity(Integer bigCapacity) {
        this.bigCapacity = bigCapacity;
    }

    public Integer getSmallCapacity() {
        return smallCapacity;
    }

    public void setSmallCapacity(Integer smallCapacity) {
        this.smallCapacity = smallCapacity;
    }

    public Integer getEnableState() {
        return enableState;
    }

    public void setEnableState(Integer enableState) {
        this.enableState = enableState;
    }

    public Integer getConnectState() {
        return connectState;
    }

    public void setConnectState(Integer connectState) {
        this.connectState = connectState;
    }

    @Override
    public String toString() {
        return "Locker{" +
                "id=" + id +
                ", locationId=" + locationId +
                ", number=" + number +
                ", type=" + type +
                ", bigCapacity=" + bigCapacity +
                ", smallCapacity=" + smallCapacity +
                ", enableState=" + enableState +
                ", connectState=" + connectState +
                '}';
    }
}
