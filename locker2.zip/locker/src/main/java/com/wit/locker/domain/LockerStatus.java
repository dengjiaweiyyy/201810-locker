package com.wit.locker.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.sql.Date;

@Entity
public class LockerStatus {

    @Id
    @GeneratedValue
    private Long id;

    private Date date;
    private Long lockerId;
    private Integer smallUseTimes;
    private Integer bigUseTimes;
    private Float smallTotalIncome;
    private Float bigTotalIncome;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Long getLockerId() {
        return lockerId;
    }

    public void setLockerId(Long lockerId) {
        this.lockerId = lockerId;
    }

    public Integer getSmallUseTimes() {
        return smallUseTimes;
    }

    public void setSmallUseTimes(Integer smallUseTimes) {
        this.smallUseTimes = smallUseTimes;
    }

    public Integer getBigUseTimes() {
        return bigUseTimes;
    }

    public void setBigUseTimes(Integer bigUseTimes) {
        this.bigUseTimes = bigUseTimes;
    }

    public Float getSmallTotalIncome() {
        return smallTotalIncome;
    }

    public void setSmallTotalIncome(Float smallTotalIncome) {
        this.smallTotalIncome = smallTotalIncome;
    }

    public Float getBigTotalIncome() {
        return bigTotalIncome;
    }

    public void setBigTotalIncome(Float bigTotalIncome) {
        this.bigTotalIncome = bigTotalIncome;
    }

    @Override
    public String toString() {
        return "LockerStatus{" +
                "id=" + id +
                ", date=" + date +
                ", lockerId=" + lockerId +
                ", smallUseTimes=" + smallUseTimes +
                ", bigUseTimes=" + bigUseTimes +
                ", smallTotalIncome=" + smallTotalIncome +
                ", bigTotalIncome=" + bigTotalIncome +
                '}';
    }
}
