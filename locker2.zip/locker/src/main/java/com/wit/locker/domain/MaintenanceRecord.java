package com.wit.locker.domain;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.sql.Date;

@Entity
public class MaintenanceRecord {

    @Id
    @GeneratedValue
    private Long id;

    private Date createTime;
    private Date updateTime;
    private Date date;
    private Long lockerId;
    private Long maintenancePersonId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Long getLockerId() {
        return lockerId;
    }

    public void setLockerId(Long lockerId) {
        this.lockerId = lockerId;
    }

    public Long getMaintenancePersonId() {
        return maintenancePersonId;
    }

    public void setMaintenancePersonId(Long maintenancePersonId) {
        this.maintenancePersonId = maintenancePersonId;
    }

    @Override
    public String toString() {
        return "MaintenanceRecordRepository{" +
                "id=" + id +
                ", createTime=" + createTime +
                ", date=" + date +
                ", lockerId=" + lockerId +
                ", maintenancePersonId=" + maintenancePersonId +
                '}';
    }
}
