package com.wit.locker.exception;

import com.wit.locker.enums.ResultEnum;

public class LockerException extends RuntimeException{

    private Integer code;

//    public LockerException(Integer code, String message) {
//        super(message);
//        this.code = code;
//    }

    public LockerException(ResultEnum resultEnum) {
        super(resultEnum.getMsg());
        this.code = resultEnum.getCode();
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

}
