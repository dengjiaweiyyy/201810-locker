package com.wit.locker.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.wit.locker.domain.Box;
import com.wit.locker.domain.CostRecord;

@Mapper
public interface BoxMapper {
	
	//根据boxid获取box
	public Box getBox(Long id);
	
	//根据lockerId,capacity获取box
	public List<Box> getBoxByLockerIdAndCapacity(Long lockerId,Long capacity);
	
	//修改box的状态
	public Integer updateBox(Box box);
	
	//查询空闲格口数
	public List<Box> getFreeBoxByLockerId(Long lockerId);
		
	
	
	
}
