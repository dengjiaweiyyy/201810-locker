package com.wit.locker.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.wit.locker.domain.ChargeScheme;
@Mapper
public interface ChargeSchemeMapper  {

}
