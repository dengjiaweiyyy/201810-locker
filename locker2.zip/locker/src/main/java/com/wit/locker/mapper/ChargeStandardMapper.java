package com.wit.locker.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.wit.locker.domain.ChargeStandard;
import com.wit.locker.domain.CostRecord;
@Mapper
public interface ChargeStandardMapper {

	//根据locker_id查询
	public ChargeStandard getChargeStandardByCapacity(Long lockerId,Long capacity);
	
	
}
