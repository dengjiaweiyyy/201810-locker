package com.wit.locker.mapper;

import com.wit.locker.domain.CostRecord;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface CostRecordMapper  {

	public CostRecord getPaymentInfo(Long id);
	
	public Long savePayment(CostRecord costRecord);
	
	public CostRecord getPayInfoByOrderId(String orderId);
	
	public CostRecord getPayInfoByOutOrderId(String outOrderId);
	
	//1.根据code获取CostRecord
	public CostRecord getPayInfoByCode(String code);
	
	//1.根据phone,code,且pay_state为1找出CostRecord
	public CostRecord getPayInfoByCodeAndPhone(String phone,String code);
		
	public Integer updatePayInfo(CostRecord costRecord);
	
	//不用付款直接修改取物状态
	public Integer updatePayInfoInFree(CostRecord costRecord);
	
	//修改取物品
	public Integer updatePayBackInfo(CostRecord costRecord);
	
	//修改异步支付回掉
	public Integer updatePayReturnBackInfo(CostRecord costRecord);
}
