package com.wit.locker.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.wit.locker.domain.Info;

@Mapper
public interface InfoMapper {
	
	//根据lockerId获取box
	public Info getInfoByLockerId(Long lockerId);
	
}
