package com.wit.locker.mapper;

import com.wit.locker.domain.Locker;

import org.apache.ibatis.annotations.Mapper;
@Mapper
public interface LockerMapper {

}
