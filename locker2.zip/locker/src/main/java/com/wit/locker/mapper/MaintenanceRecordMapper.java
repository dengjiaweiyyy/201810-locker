package com.wit.locker.mapper;

import com.wit.locker.domain.MaintenanceRecord;

import org.apache.ibatis.annotations.Mapper;
@Mapper
public interface MaintenanceRecordMapper {

}
