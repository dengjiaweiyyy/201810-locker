package com.wit.locker.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wit.locker.domain.Box;
import com.wit.locker.mapper.BoxMapper;

@Service
public class BoxService {

	@Autowired
	private BoxMapper boxMapper;
	
	//根据容量查询
	public Box getBox(Long id) {
	  return boxMapper.getBox(id);
	}
	//查询空闲格口数
	public List<Box> getFreeBox(Long lockerId){
		return boxMapper.getFreeBoxByLockerId(lockerId);
	}
	
	//根据lockerId,capacity获取box
	public Long getBoxIdByLockerIdAndCapacity(Long lockerId,Long capacity) {
		//根据lockerId,capacity获取box
		List<Box> listBox = boxMapper.getBoxByLockerIdAndCapacity(lockerId, capacity);
		if(listBox.size()==0) {
			return -1l;
		}
		return listBox.get(0).getId();
	}
	
	//根据lockerId,capacity获取box
	public List<Box> getBoxByLockerIdAndCapacity(Long lockerId,Long capacity) {
		//根据lockerId,capacity获取box
		List<Box> listBox = boxMapper.getBoxByLockerIdAndCapacity(lockerId, capacity);
		return listBox;
	}
	
	
}
