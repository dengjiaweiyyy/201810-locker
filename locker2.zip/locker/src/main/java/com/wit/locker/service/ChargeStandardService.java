package com.wit.locker.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wit.locker.domain.ChargeStandard;
import com.wit.locker.mapper.ChargeStandardMapper;

@Service
public class ChargeStandardService {

	@Autowired
	private ChargeStandardMapper chargeStandardMapper;
	
	//根据容量查询
	public ChargeStandard getChargeStandardByCapacity(Long lockerId,Long capacity) {
	  return chargeStandardMapper.getChargeStandardByCapacity(lockerId,capacity);
	}
}
