package com.wit.locker.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wit.locker.domain.ChargeStandard;
import com.wit.locker.domain.CostRecord;
import com.wit.locker.mapper.ChargeStandardMapper;
import com.wit.locker.mapper.CostRecordMapper;

@Service
public class CostRecordService {

	@Autowired
	private CostRecordMapper CostRecordMapper;
	
	//1.根据phone,code,且pay_state为1找出CostRecord
	public CostRecord getPayInfoByCodeAndPhone(String phone,String code) {
		return CostRecordMapper.getPayInfoByCodeAndPhone(phone, code);
	}
		
	//不用付款直接修改取物状态
	public Integer updatePayInfoInFree(CostRecord costRecord) {
		return CostRecordMapper.updatePayInfoInFree(costRecord);
	}
	
}
