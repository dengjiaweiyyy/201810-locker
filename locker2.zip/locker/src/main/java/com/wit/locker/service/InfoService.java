package com.wit.locker.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wit.locker.domain.Box;
import com.wit.locker.domain.Info;
import com.wit.locker.mapper.BoxMapper;
import com.wit.locker.mapper.InfoMapper;

@Service
public class InfoService {

	@Autowired
	private InfoMapper infoMapper;
	
	//根据lockerId获取box
	public Info getInfoByLockerId(Long lockerId) {
		return infoMapper.getInfoByLockerId(lockerId);
	}
	
	
}
