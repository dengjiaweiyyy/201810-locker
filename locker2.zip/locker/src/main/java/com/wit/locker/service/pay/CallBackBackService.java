package com.wit.locker.service.pay;

import java.io.IOException;
import java.util.Date;
import java.util.Map;
import java.util.Random;

import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestParam;

import com.alibaba.fastjson.JSONObject;
import com.alipay.api.AlipayApiException;
import com.alipay.api.internal.util.AlipaySignature;
import com.wit.locker.domain.Box;
import com.wit.locker.domain.CostRecord;
import com.wit.locker.mapper.BoxMapper;
import com.wit.locker.mapper.CostRecordMapper;
import com.wit.locker.service.pay.config.AlipayBackConfig;
import com.wit.locker.service.pay.config.AlipayConfig;
import com.wit.locker.utils.BaseApiService;
import com.wit.locker.utils.MsgUtil;
import com.wit.locker.utils.common.Constants;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CallBackBackService extends BaseApiService{
	
	

	@Autowired
	private CostRecordMapper costRecordMapper;
	
	@Autowired
	private BoxMapper boxMapper;
	
	
	public JSONObject synCallBack(Map<String, String> params) {
		
		log.info("###########支付宝的同步通知synCallBack开始params：{}"+params);
		JSONObject jSONObject=new JSONObject();
		//2.验签
		boolean signVerified = false;
		try {
			signVerified = AlipaySignature.rsaCheckV1(params, AlipayBackConfig.alipay_public_key, AlipayBackConfig.charset, AlipayBackConfig.sign_type);
			//——请在这里编写您的程序（以下代码仅作参考）——
			if(!signVerified) {
				jSONObject.put("result", Constants.HTTP_RES_CODE_500_VALUE);
				return jSONObject;
			}
			
			//商户订单号
			String outTradeNo =params.get("out_trade_no");
			//支付宝交易号
			String tradeNo = params.get("trade_no");
			//付款金额
			String totalAmount = params.get("total_amount");
			JSONObject data=new JSONObject();
			data.put("outTradeNo", outTradeNo);
			data.put("tradeNo", tradeNo);
			data.put("totalAmount", totalAmount);
			return data;
			
		} catch (AlipayApiException e) {
			// TODO Auto-generated catch block
			log.info("###########支付宝的同步通知synCallBack出现异常");
			jSONObject.put("result", Constants.HTTP_RES_CODE_500_VALUE);
			return jSONObject;
		} finally {
			
			log.info("###########支付宝的同步通知synCallBack结束params：{}"+params);
		}
	}
	
	
	
	
	
	
	
	//异步通知   实现线程锁
	@Transactional
	public synchronized String asynCallBack(@RequestParam Map<String, String> params)   {
		// TODO Auto-generated method stub
		//1.日志记录
		log.info("###########支付宝的同步通知synCallBack开始params：{}"+params);
		//2.验签
		boolean signVerified = false;
		try {
			signVerified = AlipaySignature.rsaCheckV1(params, AlipayBackConfig.alipay_public_key, AlipayBackConfig.charset, AlipayBackConfig.sign_type);
			//——请在这里编写您的程序（以下代码仅作参考）——
			//验签失败
			if(!signVerified) {
				return Constants.PAY_FAIL;
			}
			//商户订单号
			String outOrderId =params.get("out_trade_no");
			
			CostRecord costRecord=costRecordMapper.getPayInfoByOutOrderId(outOrderId);
			
			if(costRecord==null) {
				return Constants.PAY_FAIL;
			}
			
			Integer state=costRecord.getPayState();
			
			//如果取回已经支付就不要重复提交
			if(state==2) {
				return Constants.PAY_SUCCESS;
			}
			
			//支付宝交易号
			String tradeNo = params.get("trade_no");
			//付款金额
			String totalAmount = params.get("total_amount");
			//买家支付宝用户号
			String buyerId = params.get("buyer_id");
			
			JSONObject data=new JSONObject();
			
			//把取回支付表的支付结果标识为已经支付
			costRecord.setPayState(2);
			Integer result= costRecordMapper.updatePayReturnBackInfo(costRecord);
			//修改box的状态
			Box box = new Box();
			box.setId(costRecord.getBoxId());
			box.setState(0);
			Integer boxresult= boxMapper.updateBox(box);
			//修改失败
			if(result<=0) {
				return Constants.PAY_FAIL;
			}
			if(boxresult<=0) {
				return Constants.PAY_FAIL;
			}
			//回滚  事务手动提交
			
			return Constants.PAY_SUCCESS;
		} catch (AlipayApiException e) {
			// TODO Auto-generated catch block
			log.info("###########支付宝的同步通知synCallBack出现异常");
			e.printStackTrace();
			return Constants.PAY_FAIL;
		} finally {
			
			log.info("###########支付宝的同步通知synCallBack结束params：{}"+params);
		}
	
	}
	
	
	
	
	
	
}
