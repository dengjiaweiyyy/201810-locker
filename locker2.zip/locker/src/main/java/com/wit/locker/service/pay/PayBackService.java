package com.wit.locker.service.pay;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.DefaultAlipayClient;
import com.alipay.api.request.AlipayTradePagePayRequest;
import com.wit.locker.domain.CostRecord;
import com.wit.locker.mapper.CostRecordMapper;
import com.wit.locker.service.pay.config.AlipayBackConfig;
import com.wit.locker.service.pay.config.AlipayConfig;
import com.wit.locker.utils.BaseApiService;
import com.wit.locker.utils.OrderUtil;
import com.wit.locker.utils.ResponseBase;
import com.wit.locker.utils.common.Constants;

@Service
public class PayBackService extends BaseApiService{

	@Autowired
	private CostRecordMapper costRecordMapper;
	
	//获取取回的html
	public JSONObject getPayBackHtml(CostRecord costRecord) {
		String outOrderId = OrderUtil.getOrderIdByTime();
		JSONObject jSONObject=new JSONObject();
		costRecord.setOutOrderId(outOrderId);
		//根据id修改outOrderId，out_cost
		Integer resultUpdate = costRecordMapper.updatePayBackInfo(costRecord);
		if(resultUpdate<=0) {
			jSONObject.put("result", Constants.HTTP_RES_CODE_500_VALUE);
			return jSONObject;
		}
		
		
		
		//获得初始化的AlipayClient
		AlipayClient alipayClient = new DefaultAlipayClient(AlipayBackConfig.gatewayUrl, AlipayBackConfig.app_id, AlipayBackConfig.merchant_private_key, "json", AlipayBackConfig.charset, AlipayBackConfig.alipay_public_key, AlipayBackConfig.sign_type);
		
		//设置请求参数
		AlipayTradePagePayRequest alipayRequest = new AlipayTradePagePayRequest();
		alipayRequest.setReturnUrl(AlipayBackConfig.return_url);
		alipayRequest.setNotifyUrl(AlipayBackConfig.notify_url);
		
		
		//商户订单号，商户网站订单系统中唯一订单号，必填
		String out_trade_no =outOrderId;
		//付款金额，必填
		String total_amount = costRecord.getOutCost()+"";
		//订单名称，必填
		String subject = "小红柜取货付款";
		//商品描述，可空
		//String body = new String(request.getParameter("WIDbody").getBytes("ISO-8859-1"),"UTF-8");
		
		alipayRequest.setBizContent("{\"out_trade_no\":\""+ out_trade_no +"\"," 
				+ "\"total_amount\":\""+ total_amount +"\"," 
				+ "\"subject\":\""+ subject +"\"," 
//						+ "\"body\":\""+ body +"\"," 
				+ "\"product_code\":\"FAST_INSTANT_TRADE_PAY\"}");
		
		//若想给BizContent增加其他可选请求参数，以增加自定义超时时间参数timeout_express来举例说明
		//alipayRequest.setBizContent("{\"out_trade_no\":\""+ out_trade_no +"\"," 
		//		+ "\"total_amount\":\""+ total_amount +"\"," 
		//		+ "\"subject\":\""+ subject +"\"," 
		//		+ "\"body\":\""+ body +"\"," 
		//		+ "\"timeout_express\":\"10m\"," 
		//		+ "\"product_code\":\"FAST_INSTANT_TRADE_PAY\"}");
		//请求参数可查阅【电脑网站支付的API文档-alipay.trade.page.pay-请求参数】章节
		
		//请求 生成对应的HTML
		String result = null;
		try {
			result = alipayClient.pageExecute(alipayRequest).getBody();

			//输出
			
			
			jSONObject.put("payHtml", result);
			
			return jSONObject;
		} catch (AlipayApiException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			jSONObject.put("result", Constants.HTTP_RES_CODE_500_VALUE);
			return jSONObject;
		}
		
		
	}
	
	
	
}
