package com.wit.locker.service.pay.config;

import java.io.FileWriter;
import java.io.IOException;

/* *
 *类名：AlipayConfig
 *功能：基础配置类
 *详细：设置帐户有关信息及返回路径
 *说明：
 *以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 *该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
 */

public class AlipayBackConfig {
	
//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓

	// 应用ID,您的APPID，收款账号既是您的APPID对应支付宝账号
	public static String app_id = "2016091400513026";
	
	// 商户私钥，您的PKCS8格式RSA2私钥
    public static String merchant_private_key = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCqtPc5pYFH5hKa+fG5RLPo5TxIawZAxFf/bio0Rn28yx6Pz+29tMopisgOUg3ptkK4+Ow/OzzExdQWvmP//tuCpDBvBnnT0QArzt6T7uQaFIYVKR1FYbwpXUaAUwlypU2kIEJ6D7dNW9JfKuOl9fAUMTTCd3LhajMBTJiIBJ1kzf8/jrFjXTb3LPDbf65M+eGaxtn/WYsyBS84hXNXBprZTG+6649F97TjFWsgOe9WwFu9prXaydeRyUkC7Q7BWWsbXCIqQfEFkPFTpENMRj9OS3/2eG8PPKMnmTAUzryiMVQ+BXtdnEAE+FxpzQvlDxfjJptaUloqazUds7hNqotPAgMBAAECggEAcfcY6jJ1SfPuzeo6F88nMUABa/OPnCO4//2jTX0WKrmMcMSHWtRc9zkA8JaVVUdp6iW9S0WX/2J3gqufBWQ3VlOZRjYTlXb930Ff1XFydXroPS5SrWRfg1oTXE6TiyeS2xTybJ0bahj4LLLsgnrbyg9DwuSOHLGS1bY2SvCRx56q7yEP1pNAn0FqAFEmRU6UM36HkGHo3TxYrWaeW86YsjEkSKm9YWTZqu772uBG4PcDKVsVbyH+wL0WaGsk1dFIdV01k2COhmcYOnPCs/4iv3oEn3bt3sNXJTun6ERBU2fbYsLyP7Ek3YVri8GgjtcT61eEKRYXglHVGmf65ATWmQKBgQDmStjVj5ScwDqSzJC7XDHEkXoyJtOd/OngwxYQLLGuZ3pAFDYtSKA5VRJSHG9Cez9wtTckHPv0/aHHMjYsjLpUzUymE4IozymH7CigDV394sZX19JX3POoRWtlXhZi/Z6syoDcRR+WstMIq1bCY+5f6IKVi1ZPt+E3fENi2PJ82wKBgQC9w1JnM2yJC3Sykngub93sTvybfqqI93/90MSV6Kj5/bDYHXj4fSxyrhPosSapIQCyrHfKjbrMuIl1UgTUWzzOSWSwD2NFpabZyZ3QB+uUmDkuODJub+Iqkma6NV1Z/XRqzr1OYILEQU+MORG/QOu3MsvcAVlEgTeeFPqCi0C7nQKBgDlG7F9Rcrj55peUYXr4Fzi4phfLKF7nBJRucRJcy2SBQBqn7EGfCpq32fKqN9HlLYYuzCQjQVdRrecJSggSiFWHKkU0HO9hdwbjacdFC9eVi5dVim9n+QIlIez4VcERK2H2i849MvocR/ikBNQcXrFj9vaSzUjOhylxsqDnLIh5AoGBALHAnZa4D8nLplODafotpZauYmcRXpMQK59IiGzX1Djfz2CRMvio4BLIRzPnhQxWMr4rWcatvjX4AiKYYpe8oxekniFhOJ9LzSAigKYWVTEK6j0GPQ8/1H4GRx3T0Q7zoLJP1/nr43IMr4PtDVe2a1ZeyaDazpCh7cQxaHsSD9/tAoGAG+5T3+UJM+naf5QjKLEZj7xUjkLB/1rb4/DNdY6U16xflvxkRJJSU0jCQw0bgD8JjzCpuFWJxZKj/YyIq+pswV83oBUiMg6WDHSOiCbVcgaMgdzzCwzdhweZo48BAmAGtvhu9E7p1Z7Y9RjwKDV8R5i1Lqw70KZ6v+ObMRhISAI=";
	
	// 支付宝公钥,查看地址：https://openhome.alipay.com/platform/keyManage.htm 对应APPID下的支付宝公钥。
    public static String alipay_public_key = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAur4ippj3ot47aSYEiHAFcGX7pfQIvv9lTzDBIaK/gwlXciHbXMkPG2cRmiG9gBC7Slur4xWameJPcON8WPfw5G6ogxb+cDB3L3U8s3a8P1WUAXY+CeFKqDq99MS/EBu4HixnKLQj3yhenq2acgZRx8+FccfdzwjE4rq/1CzTWnS21TTVAsLKhvYQgLS0JM7+l4xMG1nTpAq8UOkmJldZ3GVxuFUqi/bqM2nn+WFmpZv6CS9uI1c7T3bIx6xTdOxNrV53sUA8sSrj/057EoAvVoEA4/+Ix8czf+8WsUQRW/urAkCOG/5FvW+uCo6lLdXGqs/HdD7rp5dGlxtSIMH+uQIDAQAB";

	// 服务器异步通知页面路径  需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
	public static String notify_url = "http://hhcrby.natappfree.cc/alibaba/callBackBack/notifyUrl";

	// 页面跳转同步通知页面路径 需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
	public static String return_url = "http://hhcrby.natappfree.cc/alibaba/callBackBack/returnUrl";
    
	// 签名方式
	public static String sign_type = "RSA2";
	
	// 字符编码格式
	public static String charset = "utf-8";
	
	// 支付宝网关
	public static String gatewayUrl = "https://openapi.alipaydev.com/gateway.do";
	
	// 日志文件地址
	public static String log_path = "E:\\log";


//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

    /** 
     * 写日志，方便测试（看网站需求，也可以改成把记录存入数据库）
     * @param sWord 要写入日志里的文本内容
     */
    public static void logResult(String sWord) {
        FileWriter writer = null;
        try {
            writer = new FileWriter(log_path + "alipay_log_" + System.currentTimeMillis()+".txt");
            writer.write(sWord);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

