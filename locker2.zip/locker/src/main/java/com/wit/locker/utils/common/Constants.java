package com.wit.locker.utils.common;

public interface Constants {
	
	// 响应请求成功
	String HTTP_RES_CODE_200_VALUE = "success";
	// 系统错误
	String HTTP_RES_CODE_500_VALUE = "fial";
	// 响应请求成功code
	Integer HTTP_RES_CODE_200 = 200;
	// 系统错误
	Integer HTTP_RES_CODE_500 = 500;
	// 支付成功
	String PAY_SUCCESS = "success";
	// 支付失败
	String PAY_FAIL = "fail";
	
	
}